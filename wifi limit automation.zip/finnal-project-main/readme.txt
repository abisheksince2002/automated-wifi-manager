Hai guyz This is ABISHEK B.S i am developing a wifi maintainer

kindly run below command

"bash setup.sh"


